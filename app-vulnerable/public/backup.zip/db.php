<?php
// Database config file inside zip backup
define('DB_HOST', 'db');
define('DB_USER', 'root');
define('DB_PASS', 'root_password_123');
define('DB_NAME', 'vuln_db');
?>