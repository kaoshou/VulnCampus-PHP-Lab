<?php
// Config settings
$api_key = "AIzaSyA8_TopSecretAdminKey_789x";
$jwt_secret = "super_secret_signing_key_991823";
?>